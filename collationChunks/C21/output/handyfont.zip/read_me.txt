
About Handyfont(tm) 1.0.1
=================================================================
Designed by Jonathan Macagba, (c)1994 Jonathan Macagba

A font with 52 pictographic hands. Uppercase characters contain
left and right hands in a vertical position. Lowercase
characters contain left and right hands in a horizontal
position. Comma and Period characters contain a left and right
handprint. Very "HAND"y!

HINTS and TIPS:
** String hands together to create a "hand" border.
** Use this font in your paint or drawing program to
"rubber stamp" hand shapes. Colorize to your heart's content.
** Use the hands as a fun way to "number" items from one to ten.
** Convert to paths using your favorite drawing program to
customize.

SHAREWARE FEE
=================================================================
This font is "Shareware"*. If you like and use this font,
send $5.00 to:

Jonathan Macagba
244 Fifth Avenue, Suite 2246
New York, NY 10001-7604 USA

Outside the US, make sure that your check is drawn from a US
Bank. Otherwise, please send cash.

*WHAT IS SHAREWARE?
=================================================================
Shareware is a means of distributing software on a "try before
you buy" basis. Shareware allows you to try software programs,
clip art and fonts before you purchase them. This allows you to
determine if the shareware product you are trying meets your
needs and will work with your computer equipment. After you
have tried the product, you are required to either purchase the
product or delete it from your system. The shareware concept
relies on the basic honesty of the user (or "potential buyer").
Remember that many shareware authors and developers are people
like you--not faceless corporations--and rely on the income
derived from shareware payments to continue creating software
products that make your (computer) life more productive and fun.

VERSION HISTORY
=================================================================
Version 1.0 (1994): Initial release of the font.
Version 1.0.1 (9/10/97): Address change for shareware fee.

MORE INFORMATION
=================================================================
For graphic design, illustration or custom fonts, contact me at:

Jonathan Macagba
244 Fifth Avenue, #2246
New York, NY 10001-7604
---------------------------
Tel : 212.591.0208
Email : jonathan45@aol.com
